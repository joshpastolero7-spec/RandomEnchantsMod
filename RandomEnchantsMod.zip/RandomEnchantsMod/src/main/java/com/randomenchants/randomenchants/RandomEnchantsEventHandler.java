package com.randomenchants.randomenchants;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;

public class RandomEnchantsEventHandler {

    // 20 ticks = 1 second in Minecraft
    private static final int TICK_INTERVAL = 20;

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        // Only run at END phase and on server side
        if (event.phase != TickEvent.Phase.END) return;
        if (event.player.level().isClientSide()) return;

        Player player = event.player;

        // Only trigger every 20 ticks (1 second)
        if (player.tickCount % TICK_INTERVAL != 0) return;

        // Shuffle all items in the player's inventory (main + armor + offhand)
        applyRandomEnchantsToInventory(player);
    }

    private void applyRandomEnchantsToInventory(Player player) {
        Random random = new Random();

        // Get all enchantments from the registry as a list
        List<Enchantment> allEnchantments = new ArrayList<>(ForgeRegistries.ENCHANTMENTS.getValues());

        // Iterate over all slots: hotbar (0-8), main inventory (9-35), armor (36-39), offhand (40)
        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            ItemStack stack = player.getInventory().getItem(slot);

            if (stack.isEmpty()) continue;

            // Clear existing enchantments
            stack.getEnchantmentTags().clear();

            // Apply 1 to 3 random enchantments
            int numEnchants = 1 + random.nextInt(3); // 1, 2, or 3
            Set<Enchantment> chosen = new HashSet<>();

            // Shuffle the list for randomness
            Collections.shuffle(allEnchantments, random);

            for (Enchantment enchantment : allEnchantments) {
                if (chosen.size() >= numEnchants) break;

                // Avoid incompatible combinations
                boolean compatible = chosen.stream().allMatch(e -> e.isCompatibleWith(enchantment));
                if (!compatible) continue;

                // Pick a random level between 1 and the max level of this enchantment
                // We allow going above max for a fun chaotic twist!
                int maxLevel = enchantment.getMaxLevel() + 2; // slightly above max for chaos
                int level = 1 + random.nextInt(maxLevel);

                EnchantmentHelper.setEnchantments(
                        getUpdatedEnchants(stack, enchantment, level),
                        stack
                );
                chosen.add(enchantment);
            }
        }
    }

    /**
     * Builds a new enchantment map from the item's current enchants plus the new one.
     */
    private Map<Enchantment, Integer> getUpdatedEnchants(ItemStack stack, Enchantment newEnchant, int level) {
        Map<Enchantment, Integer> enchants = new HashMap<>(EnchantmentHelper.getEnchantments(stack));
        enchants.put(newEnchant, level);
        return enchants;
    }
}
