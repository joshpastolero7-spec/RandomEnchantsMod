package com.randomenchants.randomenchants;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;

@Mod(RandomEnchantsMod.MOD_ID)
public class RandomEnchantsMod {

    public static final String MOD_ID = "randomenchants";

    public RandomEnchantsMod() {
        MinecraftForge.EVENT_BUS.register(new RandomEnchantsEventHandler());
    }
}
