# 🎲 Random Enchants Mod

**Minecraft Forge 1.20.1**

Every single second, ALL items in your inventory receive completely random enchantments. Chaos guaranteed!

---

## ✨ What It Does
- Every **20 ticks (1 second)**, each item in your inventory (hotbar, main inventory, armor, offhand) gets wiped of its old enchantments and receives **1–3 brand new random enchantments** at random levels.
- Enchantments can go slightly above their normal max level for extra chaos!
- Works on ALL items — weapons, armor, tools, and even random junk.

---

## 🛠️ How to Build

### Prerequisites
- **Java 17** (required for Minecraft 1.20.1)
- **Git** (optional)

### Steps

1. Download the [Forge MDK for 1.20.1](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html)
2. Extract the MDK and replace its `src/` folder with the `src/` folder from this project
3. Copy `build.gradle`, `settings.gradle`, and `gradle.properties` from this project into the MDK folder
4. Open a terminal in the MDK folder and run:
   ```
   gradlew genEclipseRuns   (for Eclipse)
   gradlew genIntellijRuns  (for IntelliJ)
   ```
5. Build the mod JAR:
   ```
   gradlew build
   ```
6. Find your `.jar` file in `build/libs/`

---

## 📦 Installation

1. Install [Minecraft Forge 1.20.1](https://files.minecraftforge.net/)
2. Copy the built `.jar` file into your `.minecraft/mods/` folder
3. Launch Minecraft with the Forge profile
4. Enjoy the chaos! 🎉

---

## ⚠️ Warning
This mod is **extremely chaotic** by design. Items will constantly change enchantments — great for a fun challenge run, not so great if you want stability!

---

## 📁 File Structure
```
src/main/java/com/randomenchants/randomenchants/
  ├── RandomEnchantsMod.java          ← Main mod entry point
  └── RandomEnchantsEventHandler.java ← Tick event logic

src/main/resources/
  ├── META-INF/mods.toml              ← Mod metadata
  └── pack.mcmeta                     ← Resource pack info
```
